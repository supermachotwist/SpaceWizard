Game Name: SPACE WIZARD
Game Design Document: https://space-wizard.web.app/Benchmark1/Space%20Wizard%20Game%20Design%20Document.html
