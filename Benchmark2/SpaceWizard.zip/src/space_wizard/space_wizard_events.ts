export enum space_wizard_events {
    PLAYER_FIREBALL = "player_fireball",
    PLAYER_COMET = "player_comet",
    PLAYER_LASER = "player_laser",
    PLAYER_DEATH = "player_death"
}